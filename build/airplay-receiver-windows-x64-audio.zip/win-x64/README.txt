AirPlay Receiver - Windows Portable Build
==========================================

This is a portable Windows build of the AirPlay 2 Receiver application.
No installation required - just extract and run!

## Requirements
- Windows 10 or later (64-bit)
- .NET Core 2.2 Runtime (included in this package)

## Quick Start
1. Extract all files to a directory of your choice
2. Double-click 'AirPlay.exe' to start the receiver
3. The receiver will appear on your network as "AirPlay-Receiver"
4. Connect from your iOS device or Mac to stream audio/video

That's it! The application is pre-configured and ready to use.

## Configuration (Optional)
The application is pre-configured with portable defaults. If you want to customize:

Edit the 'appsettings_win.json' file:
- AirPlayReceiver.Instance: Name shown to iOS/Mac devices (default: "AirPlay-Receiver")
- AirPlayReceiver.AirTunesPort: Port for audio streaming (default: 5000)
- AirPlayReceiver.AirPlayPort: Port for video streaming (default: 7000)
- AirPlayReceiver.DeviceMacAddress: Unique MAC address (default: AA:BB:CC:DD:EE:FF)
  Change this if you run multiple receivers on the same network!

## What's Included
- AirPlay.exe: Main application
- libfdk-aac-2.dll: AAC audio codec
- libalac-0.dll: ALAC (Apple Lossless) codec
- All required .NET Core 2.2 runtime libraries
- Pre-configured settings for portable use

## Firewall Configuration
On first run, Windows Firewall may ask for permission:
1. Check both "Private networks" and "Public networks"
2. Click "Allow access"

This allows your iOS/Mac devices to discover and connect to the receiver.

## Troubleshooting
- Not appearing on iOS/Mac? Check Windows Firewall settings
- Connection refused? Ensure ports 5000 and 7000 are not blocked
- Multiple devices? Change the DeviceMacAddress in appsettings_win.json for each instance

## Advanced
- Debug logs: Change "Default": "Warning" to "Information" in appsettings_win.json
- Dump folder: Captured streams are saved to .\dump\ (created automatically)

## Notes
- This is an open source implementation of AirPlay 2 protocol
- Built with .NET Core 2.2 and cross-compiled native codecs
- Source code: https://github.com/SteeBono/airplayreceiver
